<?php 

$lang["tables_all"] = "Всичко";
$lang["tables_columns"] = "Колони";
$lang["tables_hide_show_pagination"] = "Скриване / Показване на страници";
$lang["tables_loading"] = "Зареждане, моля изчакайте...";
$lang["tables_page_from_to"] = "Показани са {0} до {1} от {2} реда";
$lang["tables_refresh"] = "Опресняване";
$lang["tables_rows_per_page"] = "{0} редове на страница";
$lang["tables_toggle"] = "Щифт";

<?php 

$lang["datepicker_all_time"] = "Todos";
$lang["datepicker_apply"] = "Aplicar";
$lang["datepicker_cancel"] = "Cancelar";
$lang["datepicker_custom"] = "Cliente";
$lang["datepicker_from"] = "De";
$lang["datepicker_last_30"] = "Últimos 30 Dias";
$lang["datepicker_last_7"] = "Últimos 7 Dias";
$lang["datepicker_last_financial_year"] = "";
$lang["datepicker_last_month"] = "Último Mês";
$lang["datepicker_last_year"] = "Último ano";
$lang["datepicker_same_month_last_year"] = "Este mês último ano";
$lang["datepicker_same_month_to_same_day_last_year"] = "Este mês Para Hoje Último Ano";
$lang["datepicker_this_financial_year"] = "";
$lang["datepicker_this_month"] = "Este Mês";
$lang["datepicker_this_year"] = "Este Ano";
$lang["datepicker_to"] = "Para";
$lang["datepicker_today"] = "Hoje";
$lang["datepicker_today_last_year"] = "Hoje Último Ano";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_yesterday"] = "Ontem";

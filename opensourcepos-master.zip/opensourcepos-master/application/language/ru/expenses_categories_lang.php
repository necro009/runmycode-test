<?php 

$lang["category_name_required"] = "Требуется Название категории расходов";
$lang["expenses_categories_add_item"] = "Добавить Категорию";
$lang["expenses_categories_cannot_be_deleted"] = "Не удалось удалить категорию расходов";
$lang["expenses_categories_category_id"] = "ИД";
$lang["expenses_categories_confirm_delete"] = "Вы уверены, что хотите удалить выбранную категорию расходов?";
$lang["expenses_categories_description"] = "описание категории";
$lang["expenses_categories_error_adding_updating"] = "Ошибка добавления / обновления категории расходов";
$lang["expenses_categories_info"] = "Категория Информация О Расходах";
$lang["expenses_categories_name"] = "название категории";
$lang["expenses_categories_new"] = "новая категория";
$lang["expenses_categories_no_expenses_categories_to_display"] = "Нет категории для отображения";
$lang["expenses_categories_none_selected"] = "Вы не выбрали ни одной категории расходов";
$lang["expenses_categories_one_or_multiple"] = "Категория Расходов";
$lang["expenses_categories_quantity"] = "Количество";
$lang["expenses_categories_successful_adding"] = "Категория расходов  добавлена успешно";
$lang["expenses_categories_successful_deleted"] = "Категория расходов успешно удалена";
$lang["expenses_categories_successful_updating"] = "Категория расходов успешно обновлена";
$lang["expenses_categories_update"] = "Обновить Категорию";

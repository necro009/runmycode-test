<?php 

$lang["category_name_required"] = "Xərc Kategoriyası adı tələb olunur";
$lang["expenses_categories_add_item"] = "Kategoriya əlavə et";
$lang["expenses_categories_cannot_be_deleted"] = "Kategoriya Xərcləri silinmədi";
$lang["expenses_categories_category_id"] = "Kimlik";
$lang["expenses_categories_confirm_delete"] = "Seçilmiş xərc kateqoriyasını silmək istədiyinizə əminsinizmi?";
$lang["expenses_categories_description"] = "Kateqoriya təsviri";
$lang["expenses_categories_error_adding_updating"] = "Əlavədə Səhv/Xərcl Kategotiyasi yenilənir";
$lang["expenses_categories_info"] = "Xərc Kategoriyası Məlumatı";
$lang["expenses_categories_name"] = "Kategoriya adı";
$lang["expenses_categories_new"] = "Yeni Kategoriya";
$lang["expenses_categories_no_expenses_categories_to_display"] = "Heç bir kategoriya göstərilmir";
$lang["expenses_categories_none_selected"] = "Siz heç bir Xərc Kategoriyasi Seçməmisiniz";
$lang["expenses_categories_one_or_multiple"] = "Xərc Kategoriyası";
$lang["expenses_categories_quantity"] = "Miqdarı";
$lang["expenses_categories_successful_adding"] = "Xərc Kategoriyası uğurla əlavə edildi";
$lang["expenses_categories_successful_deleted"] = "Xərc Kategoriyası uğurla silindi";
$lang["expenses_categories_successful_updating"] = "Xərcləri Kateqoriya yeniləmə müvəffəqiyyətli";
$lang["expenses_categories_update"] = "Kateqoriya yeniləmə";

<?php 

$lang["login_gcaptcha"] = "";
$lang["login_go"] = "Ir";
$lang["login_invalid_gcaptcha"] = "";
$lang["login_invalid_installation"] = "";
$lang["login_invalid_username_and_password"] = "Usuario/Contraseña inválidos";
$lang["login_login"] = "Iniciar Sesión";
$lang["login_password"] = "Contraseña";
$lang["login_username"] = "Usuario";

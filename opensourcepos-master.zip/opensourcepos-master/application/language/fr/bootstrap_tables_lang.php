<?php 

$lang["tables_all"] = "Tous";
$lang["tables_columns"] = "Colonnes";
$lang["tables_hide_show_pagination"] = "Masquer/Afficher la pagination";
$lang["tables_loading"] = "Chargement en cours, patientez, s?il vous pla?t ...";
$lang["tables_page_from_to"] = "Affichage des lignes {0} à {1} sur {2} lignes au total";
$lang["tables_refresh"] = "Rafra?chir";
$lang["tables_rows_per_page"] = "{0} lignes par page";
$lang["tables_toggle"] = "Alterner";

<?php 

$lang["tables_all"] = "All";
$lang["tables_columns"] = "Spalten";
$lang["tables_hide_show_pagination"] = "Hide/Show pagination";
$lang["tables_loading"] = "Lade, bitte warten...";
$lang["tables_page_from_to"] = "Zeige {0} bis {1} von {2} Zeile(n)";
$lang["tables_refresh"] = "Refresh";
$lang["tables_rows_per_page"] = "{0} Einträge pro Seite";
$lang["tables_toggle"] = "Umschalten";

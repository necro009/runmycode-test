<?php 

$lang["login_gcaptcha"] = "";
$lang["login_go"] = "Lanjutkan";
$lang["login_invalid_gcaptcha"] = "";
$lang["login_invalid_installation"] = "";
$lang["login_invalid_username_and_password"] = "Nama Pengguna/Kata Kunci Salah";
$lang["login_login"] = "Masuk";
$lang["login_password"] = "Kata kunci";
$lang["login_username"] = "Nama Anda";

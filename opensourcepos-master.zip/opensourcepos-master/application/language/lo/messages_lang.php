<?php 

$lang["messages_first_name"] = "ຊື່";
$lang["messages_last_name"] = "ນາມສະກຸນ";
$lang["messages_message"] = "ຂໍ້ຄວາມ";
$lang["messages_message_placeholder"] = "ໃສ່ຂໍ້ຄວາມຂອງທ່ານບ່ອນນີ້...";
$lang["messages_message_required"] = "ຂໍ້ຄວາມຈຳເປັນຕ້ອງໃສ່";
$lang["messages_multiple_phones"] = "(ໃນກໍລະນີມີຜູ້ຮັບຫຼາຍຄົນ, ໃຫ້ໃສ່ເບີໂທຂັ້ນດ້ວຍໝາຍຈຸດ)";
$lang["messages_phone"] = "ເບີໂທ";
$lang["messages_phone_number_required"] = "ເບີໂທຈຳເປັນຕ້ອງໃສ່";
$lang["messages_phone_placeholder"] = "ໃສ່ເບີໂທບ່ອນນີ້...";
$lang["messages_sms_send"] = "ສົ່ງ SMS";
$lang["messages_successfully_sent"] = "ສົ່ງຂໍ້ຄວາມສຳເລັດ ໄປຫາ: ";
$lang["messages_unsuccessfully_sent"] = "ສົ່ງຂໍ້ຄວາມບໍ່ສຳເລັດ ໄປຫາ: ";

<?php 

$lang["datepicker_all_time"] = "ເວລາທັງໝົດ";
$lang["datepicker_apply"] = "ນຳໃຊ້";
$lang["datepicker_cancel"] = "ຍົກເລີກ";
$lang["datepicker_custom"] = "ປັບແຕ່ງ";
$lang["datepicker_from"] = "ເລີ່ມຈາກ";
$lang["datepicker_last_30"] = "30 ວັນຜ່ານມາ";
$lang["datepicker_last_7"] = "7 ວັນຜ່ານມາ";
$lang["datepicker_last_financial_year"] = "1 ປີຜ່ານມາ";
$lang["datepicker_last_month"] = "ເດືອນແລ້ວນີ້";
$lang["datepicker_last_year"] = "ປີກາຍນີ້";
$lang["datepicker_same_month_last_year"] = "ເດືອນນີ້ຂອງປີກາຍ";
$lang["datepicker_same_month_to_same_day_last_year"] = "ມື້ນີ້ ເດືອນນີ້ ຂອງປີກາຍ";
$lang["datepicker_this_financial_year"] = "ສົກປີນີ້";
$lang["datepicker_this_month"] = "ເດືອນປັດຈຸບັນ";
$lang["datepicker_this_year"] = "ປີປັດຈຸບັນ";
$lang["datepicker_to"] = "ເຖິງ";
$lang["datepicker_today"] = "ມື້ນີ້";
$lang["datepicker_today_last_year"] = "ມື້ນີ້ຂອງປີກາຍ";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_yesterday"] = "ມື້ວານນີ້";

<?php 

$lang["login_gcaptcha"] = "ຂ້ອຍບໍ່ແມ່ນເຄື່ອງຈັກ.";
$lang["login_go"] = "Go";
$lang["login_invalid_gcaptcha"] = "ຍັງບໍ່ໄດ້ຕິກ ຂ້ອຍບໍ່ແມ່ນເຄື່ອງຈັກ.";
$lang["login_invalid_installation"] = "ການຕິດຕັ້ງມີຂໍ້ຜິດພາດ, ກະລຸນາກວດສອບ php.ini file.";
$lang["login_invalid_username_and_password"] = "Username ຫຼື Password ບໍ່ຖືກຕ້ອງ.";
$lang["login_login"] = "ເຂົ້າລະບົບ";
$lang["login_password"] = "Password";
$lang["login_username"] = "Username";
